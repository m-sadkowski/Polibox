package pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory;

import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.Wedrowka;

public class Bagno extends Wedrowka {


    /**
     * @param odleglosc - długość wędrówki w GOTach
     */
    public Bagno(double odleglosc) {
        super(odleglosc);
    }

    @Override
    public String getNazwa() {
        return "Przeprawa przez bagna";
    }

    @Override
    public double modyfikujPredkoscGrupy(double predkosc) {
        return predkosc * 0.7;
    }

    @Override
    public int getTrudnoscNawigacyjna() {
        return 5;
    }
}
