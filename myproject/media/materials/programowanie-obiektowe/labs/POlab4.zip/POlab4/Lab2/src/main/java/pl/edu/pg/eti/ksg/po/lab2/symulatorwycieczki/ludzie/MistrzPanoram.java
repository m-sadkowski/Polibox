package pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.ludzie;

import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.Atrakcja;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.Wedrowka;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.beskidy.Panorama;

public class MistrzPanoram extends Czlowiek {
    public MistrzPanoram(String imie, String nazwisko, Plec plec) {
        super(imie, nazwisko, plec, 5.0f);
    }

    @Override
    public int getUmiejetnosciNawigacyjne() {
        return 5;
    }

    @Override
    public void reagujNaAtrakcje(Atrakcja a, double czas) {
        double dodatkoweZmeczenie = czas / getCzasPelnegoZmeczenia();
        if(a instanceof Panorama){
            setPoziomZmeczenia(Math.max(getPoziomZmeczenia() - 3 * dodatkoweZmeczenie, 0.0));
            System.out.println("Poziom zmęczenia u " + getImie() + " " + getNazwisko() + " zmalal o " + 3 * dodatkoweZmeczenie
                    + " i wynosi " + getPoziomZmeczenia() + ".");
            System.out.println("Panorama!");
        }
        else
        {
            setPoziomZmeczenia(Math.max(getPoziomZmeczenia() - dodatkoweZmeczenie, 0.0));
            System.out.println("Poziom zmęczenia u " + getImie() + " " + getNazwisko() + " zmalal o " + dodatkoweZmeczenie
                    + " i wynosi " + getPoziomZmeczenia() + ".");
        }
    }

    @Override
    public void reagujNaWedrowke(Wedrowka w, double czas) {
        aktualizujZmeczenie(czas);
        mow("Hmm, wędrówka: "+w.getNazwa());
    }
}