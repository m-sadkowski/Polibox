package pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.ludzie;

import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.Atrakcja;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.Wedrowka;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.Bagno;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.PrzeprawaPrzezRzeke;

public class BagiennyBiegacz extends Czlowiek {
    public BagiennyBiegacz(String imie, String nazwisko, Plec plec) {
        super(imie, nazwisko, plec, 5.0f);
    }

    @Override
    public int getUmiejetnosciNawigacyjne() {
        return 6;
    }

    @Override
    public void reagujNaAtrakcje(Atrakcja a, double czas) {
        double dodatkoweZmeczenie = czas / getCzasPelnegoZmeczenia();
        setPoziomZmeczenia(Math.max(getPoziomZmeczenia() - dodatkoweZmeczenie, 0.0));
        System.out.println("Poziom zmęczenia u " + getImie() + " " + getNazwisko() + " zmalal o " + dodatkoweZmeczenie
                + " i wynosi " + getPoziomZmeczenia() + ".");
    }

    @Override
    public void reagujNaWedrowke(Wedrowka w, double czas) {
        if(w instanceof Bagno)
        {
            aktualizujZmeczenie(czas / 2);
            mow("Moje bagno: "+w.getNazwa() + "!");
        }
        else
        {
            aktualizujZmeczenie(czas);
            mow("Hmm, wędrówka: "+w.getNazwa());
        }

    }
}
