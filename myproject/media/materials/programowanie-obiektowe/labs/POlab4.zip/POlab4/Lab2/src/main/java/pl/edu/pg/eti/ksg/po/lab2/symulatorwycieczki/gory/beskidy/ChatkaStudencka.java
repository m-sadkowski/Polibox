package pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.beskidy;

import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.Atrakcja;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.ElementWycieczki;

public class ChatkaStudencka extends Atrakcja {

    private String nazwaKlubu = "PG GÓRA!";

    public ChatkaStudencka() {
        setCzasZwiedzania(0.75f);
    }

    @Override
    public String getNazwa() {
        return "Chatka Studencka";
    }

    public String getNazwaKlubu() {
        return nazwaKlubu;
    }
}
