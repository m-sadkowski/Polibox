package pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.beskidy;

import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.Atrakcja;

public class DrewnianaCerkiew extends Atrakcja {

    private String miejscowosc;

    public DrewnianaCerkiew(String miejscowosc) {
        this.miejscowosc = miejscowosc;
        setCzasZwiedzania(0.5f);
    }

    public String getMiejscowosc() {
        return miejscowosc;
    }

    @Override
    public String getNazwa() {
        return "Drewniana Cerkiew";
    }
}
