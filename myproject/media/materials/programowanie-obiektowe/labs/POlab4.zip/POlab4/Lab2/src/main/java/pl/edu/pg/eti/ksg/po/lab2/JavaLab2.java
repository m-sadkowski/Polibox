package pl.edu.pg.eti.ksg.po.lab2;

import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.*;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.*;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.beskidy.ChatkaStudencka;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.beskidy.DrewnianaCerkiew;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.beskidy.Panorama;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.gory.beskidy.Schronisko;
import pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki.ludzie.*;

import java.util.HashSet;
import java.util.Set;

/**
 * @author TB
 */
public class JavaLab2 {
    public static void main(String[] args) {
        Wycieczka w = doDydiowki();
        Wycieczka w2 = doLaboratorium();

        PrzewodnikStudencki przewodnik = new PrzewodnikStudencki("Stefan", "Długonogi", Czlowiek.Plec.MEZCZYZNA);
        Set<Uczestnik> uczestnicy = new HashSet<>();
        uczestnicy.add(new Student("Alojzy", "Mechanik", Czlowiek.Plec.MEZCZYZNA));
        uczestnicy.add(new Student("Ada", "Lovelace", Czlowiek.Plec.KOBIETA));
        uczestnicy.add(new Student("Jan", "Elektronik", Czlowiek.Plec.MEZCZYZNA));
        uczestnicy.add(new StudentKSG("Piotr", "Teledetekcyjny", Czlowiek.Plec.MEZCZYZNA));

        uczestnicy.add(new Lesmian("Jan", "Tsiupa", Czlowiek.Plec.MEZCZYZNA));
        uczestnicy.add(new Wierzacy("Dawid", "Smutny", Czlowiek.Plec.MEZCZYZNA));
        uczestnicy.add(new StudentETI("Jakub", "Chudy", Czlowiek.Plec.MEZCZYZNA));
        uczestnicy.add(new MistrzPanoram("Jan", "Szybki", Czlowiek.Plec.MEZCZYZNA));
        uczestnicy.add(new BagiennyBiegacz("Dobroslawa", "Dobra", Czlowiek.Plec.KOBIETA));

        Grupa g = new Grupa(przewodnik, uczestnicy);

        Grupa g2 = new Grupa(przewodnik, uczestnicy);

        //SymulatorWycieczki symulator = new SymulatorWycieczki(g, w);

        //symulator.addSluchaczPostepow((ElementWycieczki elementWycieczki, int lp, int liczbaElementow) -> System.out.println("progres: " + (lp + 1) + " z " + liczbaElementow));

        //symulator.symuluj();

        SymulatorWycieczki symulator2 = new SymulatorWycieczki(g2, w2);

        symulator2.addSluchaczPostepow((ElementWycieczki elementWycieczki, int lp, int liczbaElementow) -> System.out.println("progres: " + (lp + 1) + " z " + liczbaElementow));

        symulator2.symuluj();
    }

    public static Wycieczka doDydiowki() {
        Wycieczka ret = new Wycieczka("Do Dydiówki");
        ret.dodajElementWycieczki(new Droga(1.0));
        ret.dodajElementWycieczki(new DrewnianaCerkiew("Smolnik"));
        ret.dodajElementWycieczki(new Droga(5.0));
        ret.dodajElementWycieczki(new PrzeprawaPrzezRzeke(1.0));
        ret.dodajElementWycieczki(new GestyLas(2.0));
        ret.dodajElementWycieczki(new ChatkaStudencka());
        ret.dodajElementWycieczki(new Las(2.0));
        ret.dodajElementWycieczki(new Droga(4.0));
        ret.dodajElementWycieczki(new PrzeprawaPrzezRzeke(2.0));
        ret.dodajElementWycieczki(new DrewnianaCerkiew("Koluszki Podhalańskie"));
        ret.dodajElementWycieczki(new Droga(3.0));
        ret.dodajElementWycieczki(new Schronisko("Karpaczowo"));
        ret.dodajElementWycieczki(new Bagno(2.0));
        return ret;
    }

    public static Wycieczka doLaboratorium() {
        Wycieczka ret = new Wycieczka("Do Laboratorium");
        ret.dodajElementWycieczki(new Droga(5.0));
        ret.dodajElementWycieczki(new Las(2.0));
        ret.dodajElementWycieczki(new GestyLas(4.0));
        ret.dodajElementWycieczki(new Schronisko("Karpaczowo"));
        ret.dodajElementWycieczki(new Bagno(2.0));
        ret.dodajElementWycieczki(new Panorama());
        ret.dodajElementWycieczki(new GestyLas(3.0));
        return ret;
    }

}
