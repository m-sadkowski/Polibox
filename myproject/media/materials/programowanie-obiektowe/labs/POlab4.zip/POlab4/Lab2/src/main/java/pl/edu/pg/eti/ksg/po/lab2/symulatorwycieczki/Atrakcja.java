package pl.edu.pg.eti.ksg.po.lab2.symulatorwycieczki;

public abstract class Atrakcja implements ElementWycieczki{
    private float czasZwiedzania;

    public Atrakcja() {
    }

    public float getCzasZwiedzania() {
        return czasZwiedzania;
    }

    public void setCzasZwiedzania(float czasZwiedzania) {
        this.czasZwiedzania = czasZwiedzania;
    }
}
