public class Punkt {
    private final double x,y;
    public Punkt(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Punkt) {
            Punkt other = (Punkt)obj;
            if(x == other.getX() && y == other.getY())
                return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        int pierwsza = 59;
        int wynik = 7;
        wynik = (int) (x * pierwsza + wynik);
        wynik = (int) (y * pierwsza + wynik);
        return wynik;
    }

    @Override
    public String toString() {
        return "Punkt{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }

    public static final Punkt O = new Punkt(0, 0);

    public static final Punkt E_X = new Punkt(1, 0);

    public static final Punkt E_Y = new Punkt(0, 1);

}
