public class Symetria implements Transformacja {
    private final char os;

    public Symetria(char os) {
        this.os = os;
    }

    @Override
    public String toString() {
        return "Symetria wzgledem " + os;
    }

    private Punkt oOX(Punkt p)
    {
        return new Punkt(-p.getX(),p.getY());
    }

    private Punkt oOY(Punkt p)
    {
        return new Punkt(p.getX(),-p.getY());
    }

    private Punkt oOO(Punkt p)
    {
        return new Punkt(oOX(p).getX(),oOY(p).getY());
    }

    @Override
    public Punkt transformuj(Punkt p) {
        if(os == 'X') {
            return oOX(p);
        }
        else if (os == 'Y') {
            return oOY(p);
        }
        else if (os == 'O') {
            return oOO(p);
        }
        else
        {
            return p;
        }
    }

    @Override
    public Transformacja getTransformacjaOdwrotna() throws BrakTransformacjiOdwrotnejException {
        switch (os) {
            case 'X':
                return new Symetria('X');
            case 'Y':
                return new Symetria('Y');
            case 'O':
                return new Symetria('O');
            default:
                throw new BrakTransformacjiOdwrotnejException("Brak transformacji odwrotnej dla osi: " + os);
        }
    }


}