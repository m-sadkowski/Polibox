public class BrakTransformacjiOdwrotnejException extends Exception{

    public BrakTransformacjiOdwrotnejException() {
    }

    public BrakTransformacjiOdwrotnejException(String message) {
        super(message);
    }

    public BrakTransformacjiOdwrotnejException(String message, Throwable cause) {
        super(message, cause);
    }

    public BrakTransformacjiOdwrotnejException(Throwable cause) {
        super(cause);
    }

}
