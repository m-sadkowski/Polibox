public class Main {
    public static void main(String[] args) {

        /*
        try {
            Punkt p1 = Punkt.E_X;
            System.out.println(p1);
            Transformacja tr = new Translacja(5, 6);
            System.out.println(tr);
            Punkt p2 = tr.transformuj(p1);
            System.out.println(p2);
            Transformacja trr = tr.getTransformacjaOdwrotna();
            System.out.println(trr);
            Punkt p3 = trr.transformuj(p2);
            System.out.println(p3);

        } catch (BrakTransformacjiOdwrotnejException ex)
        {
            ex.printStackTrace();
        }
        System.out.println();

        try
        {
            Punkt p1 = new Punkt(2, 2);
            System.out.println(p1);
            Transformacja tr2 = new Skalowanie(5, 4);
            System.out.println(tr2);
            Punkt p2 = tr2.transformuj(p1);
            System.out.println(p2);
            Transformacja trr2 = tr2.getTransformacjaOdwrotna();
            System.out.println(trr2);
            Punkt p3 = trr2.transformuj(p2);
            System.out.println(p3);
        }
        catch(BrakTransformacjiOdwrotnejException ex)
        {
            ex.printStackTrace();
        }
        System.out.println();

        try
        {
            Punkt p1 = new Punkt(2, 2);
            Transformacja tr2 = new Skalowanie(5, 3);
            System.out.println(tr2);
            System.out.println(p1);
            Punkt p2 = tr2.transformuj(p1);
            System.out.println(p2);
            Transformacja trr2 = tr2.getTransformacjaOdwrotna();
            System.out.println(trr2);
            Punkt p3 = trr2.transformuj(p2);
            System.out.println(p3);
        }
        catch(BrakTransformacjiOdwrotnejException ex)
        {
            ex.printStackTrace();
        }
        System.out.println();

        try
        {
            Punkt p1 = new Punkt(2, 2);
            Transformacja tr2 = new Obrot(30);
            System.out.println(tr2);
            System.out.println(p1);
            Punkt p2 = tr2.transformuj(p1);
            System.out.println(p2);
            Transformacja trr2 = tr2.getTransformacjaOdwrotna();
            System.out.println(trr2);
            Punkt p3 = trr2.transformuj(p2);
            System.out.println(p3);
        }
        catch(BrakTransformacjiOdwrotnejException ex)
        {
            ex.printStackTrace();
        }
        System.out.println();
        */

/*
        Punkt p3 = new Punkt(2, 2);
        Obrot o =  new Obrot(30);
        System.out.println(p3);
        System.out.println(p3.equals(o.transformuj(p3)));
*/


        try {
            Punkt p1 = new Punkt(2.0, 2.0);
            Transformacja[] transformuj1 = new Transformacja[9];
            Transformacja tr1 = new Skalowanie(1, 4);
            Transformacja tr2 = new Skalowanie(5, 2);
            Transformacja tr3 = new Translacja(5, 6);
            Transformacja tr4 = new Obrot(0);
            Transformacja tr5 = new Skalowanie(3, 1);
            Transformacja tr6 = new Translacja(-5, 2);
            Transformacja tr7 = new Symetria('X');
            Transformacja tr8 = new Symetria('Y');
            Transformacja tr9 = new Symetria('O');
            transformuj1[0] = tr1;
            transformuj1[1] = tr2;
            transformuj1[2] = tr3;
            transformuj1[3] = tr4;
            transformuj1[4] = tr5;
            transformuj1[5] = tr6;
            transformuj1[6] = tr7;
            transformuj1[7] = tr8;
            transformuj1[8] = tr9;
            ZlozenieTransformacji zl = new ZlozenieTransformacji(transformuj1);
            System.out.println(p1.equals(zl.getTransformacjaOdwrotna().transformuj(zl.transformuj(p1))));
        }
        catch(BrakTransformacjiOdwrotnejException ex)
        {
            ex.printStackTrace();
        }
        System.out.println();
    }
}