import java.util.Arrays;

public class ZlozenieTransformacji implements Transformacja{
    private final Transformacja[] tab;
    public ZlozenieTransformacji(Transformacja[] tab) {
        this.tab = tab;
    }

    @Override
    public Punkt transformuj(Punkt p) {
        for(Transformacja t : tab) {
            p = t.transformuj(p);
            System.out.println("Po transformacji: " + t + ": " + p);
        }
        return p;
    }

    @Override public Transformacja getTransformacjaOdwrotna() throws BrakTransformacjiOdwrotnejException {
        Transformacja[] odwrotna = new Transformacja[tab.length];
        int j = 0;
        for(int i = tab.length - 1; i >= 0; i--)
        {
            odwrotna[j] = tab[i].getTransformacjaOdwrotna();
            j++;
        }
        return new ZlozenieTransformacji(odwrotna);
    }
}
