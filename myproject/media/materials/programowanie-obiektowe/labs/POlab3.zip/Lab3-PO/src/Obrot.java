import static java.lang.Math.cos;
import static java.lang.Math.sin;

public class Obrot implements Transformacja {

    private final double kat;
    public Obrot(double kat) {
        this.kat = kat;
    }

    @Override
    public Transformacja getTransformacjaOdwrotna() throws BrakTransformacjiOdwrotnejException {
        //if(Math.sin(kat) == 0 || Math.cos(kat) == 0)
          //  throw new BrakTransformacjiOdwrotnejException("Brak transformacji odwrotnej - dla tego kata sin lub cos jest rowny 0");
        return new Obrot(-kat);
    }

    @Override
    public Punkt transformuj(Punkt p) {
        return new Punkt(p.getX() * Math.cos(kat) - p.getY() * Math.sin(kat), p.getX() * Math.sin(kat) + p.getY() * Math.cos(kat));
    }

    public double getKat() {
        return kat;
    }

    @Override
    public String toString() {
        return "Obrot o kat " + kat;
    }
}
