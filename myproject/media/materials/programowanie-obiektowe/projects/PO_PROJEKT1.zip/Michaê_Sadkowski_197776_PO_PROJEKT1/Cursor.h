#pragma once
#include <Windows.h>

void gotoxy(int x, int y);