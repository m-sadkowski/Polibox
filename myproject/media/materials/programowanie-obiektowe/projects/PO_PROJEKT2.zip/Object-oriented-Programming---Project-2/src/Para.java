public class Para {
    public int x, y;
    public Para(int x, int y) {
        this.x = x;
        this.y = y;
    }
}

